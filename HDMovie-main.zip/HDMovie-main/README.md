# CINEMAA

CINEMAA is a website where you can stream different movies and tv shows for free. This is made purely for education purpose. i made this websit as my first big project when i was just a beginner in web development. since then i have learned alot.

## Screenshots

![App Screenshot](https://iwebp.extraimage.xyz/webp/auto/90/CJEW4LsOK5MjRukb_p_ok3T3ag77TJaDA1pcToko9C5BHdq9VKD0UBcqWUA7CG9pE7bUzs.webp)
![App Screenshot](https://iwebp.extraimage.xyz/webp/auto/90/CJEW4LsOK5MjRukb_p_ok3T3ag77TJaDA1pcToko9C5BHdq9VKD0UBcqWUA7CY97w7bUzs.webp)
![App Screenshot](https://iwebp.extraimage.xyz/webp/auto/90/CJEW4LsOK5MjRukb_p_ok3T3ag77TJaDA1pcToko9C5BHdq9VKD0UBcqWUA7Cr_s_5k7bUzs.webp)
![App Screenshot](https://iwebp.extraimage.xyz/webp/auto/90/CJEW4LsOK5MjRukb_p_ok3T3ag77TJaDA1pcToko9C5BHdq9VKD0UBcqWUA7C98qc7bUzs.webp)

## Demo

www.cinemaa.ga

## Features

- Light/dark mode toggle
- Full HD quality movies and TV shows
- Subtitles Available
- Various movies and TV shows based on genre
- Trailer Available
- Moives and TV shows includes Cast name
- Search any Moives, TV shows, Actors
- Resposive for all devices
- No Ad

## License

[MIT](https://github.com/immdipu/CINEMAA/blob/main/LICENSE)

![Logo](https://iwebp.extraimage.xyz/webp/auto/90/CJEW4LsOK5MjRukb_p_ok3T3ag77TJaDA1pcToko9C5BHdq9VKD0UBcqWUA7De_s_po7bUzs.webp)

## Future plans

I might recreate this whole website from scratch using React framework to make it more faster and efficient. i am also thinking about adding a "Add to my Favorite list" feature.

## 🔗 Links

[![linkedin](https://img.shields.io/badge/linkedin-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/immdipu)
[![twitter](https://img.shields.io/badge/twitter-1DA1F2?style=for-the-badge&logo=twitter&logoColor=white)](https://www.linkedin.com/in/dipu-chaurasiya-988786213/)
